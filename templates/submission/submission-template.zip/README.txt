SLE private submission package

Complete task-plan.md and reference-rankings.xlsx; add supporting data under data/. Explain each column, units, missing values and ranking direction.
Do not include passwords, API keys or unrelated personal information.
A ZIP upload is intake only: it is not extracted or executed, and is not a scientific or AI review pass.
